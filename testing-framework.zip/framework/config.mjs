const config = {
  baseUrl: 'http://localhost:3000',
  apiKey: 'your-api-key',
  env: 'development',
};

export default config;
